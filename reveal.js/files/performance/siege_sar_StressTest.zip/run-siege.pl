#!/usr/bin/perl
# run-siege.pl

use strict;
use warnings;

my $rptfile = 'siege.log';
my $user_agent = "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100501 Iceweasel/3.5.9 (like Firefox/3.5.9)";
my $siegerc = '/dev/null';

my $cfgfile;
my @params;

my $users;
my $run_time;
my $delay;
my $logmark;
my $urlfile;
my $logfile;
my $sleep;

my $cmd;

if(!defined($ARGV[0])) {
  printf("Please provide a configuration file\n");
  die;
}

open(INFILE,$ARGV[0]);

# <> construct means read one line; undefined response signals EOF
while ($cfgfile = <INFILE>) {
  chomp($cfgfile);
  @params = split(",",$cfgfile);

  $users = $params[0];
  $run_time = $params[1];
  $delay = $params[2];
  $logmark = $params[3];
  $urlfile = $params[4];
  $logfile = $params[5];
  $sleep = $params[6];
  # Removing CRLF from last field
  # $sleep =~ s/\n//g;
  # Use chomp() instead

  $cmd = 'siege -R ' . $siegerc . ' -v -m ' . $logmark . ' -c ' . $users . ' -i -f ' . $urlfile . ' -d ' . $delay . ' -t ' . $run_time . ' -A "' . $user_agent . '" --log=' . $rptfile . ' > ' . $logfile;

  printf("===================================================================\n");
  printf($logmark . "\n");
  printf("===================================================================\n");
  
  printf($cmd . "\n");
  # system($cmd);
  
  printf('Sleeping ' . $sleep . " seconds\n");
  sleep $sleep
}
